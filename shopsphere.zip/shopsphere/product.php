<?php
require_once 'config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if(!$p) redirect('/products.php');

$pageTitle = $p['name'];
require_once 'partials/header.php';

$rel=$conn->prepare("SELECT id,name,price,image_url FROM products WHERE category=? AND id!=? LIMIT 4");
$rel->bind_param('si',$p['category'],$p['id']);
$rel->execute();
$related=$rel->get_result();
?>

<div class="breadcrumb">
  <div class="container bc-inner">
    <a href="<?= SITE_URL ?>/index.php">Home</a><span>›</span>
    <a href="<?= SITE_URL ?>/products.php">Products</a><span>›</span>
    <a href="<?= SITE_URL ?>/products.php?category=<?= urlencode($p['category']) ?>"><?= e($p['category']) ?></a><span>›</span>
    <span><?= e($p['name']) ?></span>
  </div>
</div>

<section class="pd-section">
  <div class="container pd-grid">

    <!-- IMAGE -->
    <div class="pd-img-col">
      <div class="pd-img-box">
        <img src="<?= e($p['image_url']) ?>" alt="<?= e($p['name']) ?>" id="mainImg">
      </div>
    </div>

    <!-- INFO -->
    <div class="pd-info">
      <span class="pd-cat-tag"><?= e($p['category']) ?></span>
      <h1><?= e($p['name']) ?></h1>
      <div class="pd-stars">★★★★★ <span>4.8 · 124 reviews</span></div>

      <div class="pd-price-box">
        <span class="pd-price"><?= price((float)$p['price']) ?></span>
        <span class="pd-was"><?= price((float)$p['price']*1.25) ?></span>
        <span class="pd-save">25% OFF</span>
      </div>

      <p class="pd-desc"><?= e($p['description']) ?></p>

      <div class="pd-perks">
        <div>✓ Free delivery on orders above ₹999</div>
        <div>✓ 30-day hassle-free returns</div>
        <div>✓ 1 year manufacturer warranty</div>
        <div>✓ 100% genuine product</div>
      </div>

      <form action="<?= SITE_URL ?>/add_to_cart.php" method="POST" class="pd-cart-form">
        <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
        <div class="qty-row">
          <label>Quantity</label>
          <div class="qty-ctrl">
            <button type="button" onclick="chQty(-1)">−</button>
            <input type="number" name="quantity" id="qInp" value="1" min="1" max="99">
            <button type="button" onclick="chQty(1)">+</button>
          </div>
        </div>
        <div class="pd-actions">
          <button type="submit" class="btn-atc">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            Add to Cart
          </button>
          <a href="<?= SITE_URL ?>/products.php" class="btn-back-p">← Back</a>
        </div>
      </form>
    </div>

  </div>
</section>

<?php if($related->num_rows>0): ?>
<section class="section bg-section">
  <div class="container">
    <div class="sec-head">
      <div><p class="sec-tag">More Like This</p><h2 class="sec-title">Related Products</h2></div>
    </div>
    <div class="prod-grid">
      <?php while($row=$related->fetch_assoc()): ?>
      <div class="pcard">
        <div class="pcard-img">
          <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>">
            <img src="<?= e($row['image_url']) ?>" alt="<?= e($row['name']) ?>" loading="lazy">
          </a>
          <div class="pcard-ov">
            <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>" class="ov-btn">View</a>
          </div>
        </div>
        <div class="pcard-body">
          <h3><a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>"><?= e($row['name']) ?></a></h3>
          <div class="pcard-foot">
            <span class="pcard-price"><?= price((float)$row['price']) ?></span>
            <form action="<?= SITE_URL ?>/add_to_cart.php" method="POST">
              <input type="hidden" name="product_id" value="<?= (int)$row['id'] ?>">
              <input type="hidden" name="quantity" value="1">
              <button class="add-btn" type="submit">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              </button>
            </form>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<script>
function chQty(d){const i=document.getElementById('qInp');i.value=Math.max(1,Math.min(99,(parseInt(i.value)||1)+d));}
</script>

<?php require_once 'partials/footer.php'; ?>
