<?php
require_once 'config.php';
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('/cart.php');
$pid=(int)($_POST['product_id']??0);
$qty=(int)($_POST['quantity']??1);
if(isset($_SESSION['cart'][$pid])){
    if($qty<=0) unset($_SESSION['cart'][$pid]);
    else $_SESSION['cart'][$pid]['quantity']=$qty;
}
redirect('/cart.php');
