<?php
if (session_status() === PHP_SESSION_NONE) session_start();

define('SITE_NAME', 'ShopSphere');
define('SITE_URL',  '/shopsphere');
define('CURRENCY',  '₹');

$host   = 'localhost';
$dbname = 'shopsphere_db';
$user   = 'root';
$pass   = '';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>DB Error</title>
    <style>body{font-family:sans-serif;background:#0a0a0a;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
    .box{background:#111;border:1px solid #333;border-radius:16px;padding:40px;max-width:500px;text-align:center;}
    h2{color:#f87171;margin-bottom:12px;}p{color:#888;line-height:1.7;}code{color:#fbbf24;}</style>
    </head><body><div class="box">
    <h2>⚠ Database Connection Failed</h2>
    <p>Error: <code>' . $conn->connect_error . '</code></p>
    <p>Make sure XAMPP MySQL is running and you have imported<br><code>database/shopsphere_db.sql</code> in phpMyAdmin.</p>
    </div></body></html>');
}
$conn->set_charset('utf8mb4');

function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function price(float $p): string { return CURRENCY . number_format($p, 2); }
function isLoggedIn(): bool { return isset($_SESSION['user_id']); }
function redirect(string $path): void { header('Location: ' . SITE_URL . $path); exit; }

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
function cartCount(): int { $n=0; foreach($_SESSION['cart'] as $i) $n+=(int)$i['quantity']; return $n; }
function cartTotal(): float { $t=0; foreach($_SESSION['cart'] as $i) $t+=$i['price']*$i['quantity']; return $t; }
