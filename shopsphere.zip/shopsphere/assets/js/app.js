/* ShopSphere — app.js */
document.addEventListener('DOMContentLoaded', () => {

  /* Page loader */
  const loader = document.getElementById('pageLoader');
  if(loader){ window.addEventListener('load',()=>loader.classList.add('gone')); setTimeout(()=>loader.classList.add('gone'),2200); }

  /* Sticky header */
  const hdr = document.getElementById('siteHeader');
  if(hdr) window.addEventListener('scroll',()=>hdr.classList.toggle('scrolled',scrollY>10));

  /* Search toggle */
  const sBtn = document.getElementById('searchToggle');
  const sDrop = document.getElementById('searchDrop');
  if(sBtn&&sDrop){
    sBtn.addEventListener('click',()=>{ sDrop.classList.toggle('open'); if(sDrop.classList.contains('open')) sDrop.querySelector('input')?.focus(); });
    document.addEventListener('keydown',e=>{ if(e.key==='Escape') sDrop.classList.remove('open'); });
  }

  /* User dropdown */
  const uBtn = document.getElementById('uBtn');
  const uDrop = document.getElementById('uDrop');
  if(uBtn&&uDrop){
    uBtn.addEventListener('click',e=>{ e.stopPropagation(); uDrop.classList.toggle('open'); });
    document.addEventListener('click',()=>uDrop.classList.remove('open'));
  }

  /* Hamburger */
  const ham = document.getElementById('hamburger');
  const nav = document.getElementById('mainNav');
  if(ham&&nav){ ham.addEventListener('click',()=>{ nav.classList.toggle('open'); }); }

  /* Flash toast */
  const fd = document.getElementById('flashData');
  if(fd) showToast(fd.dataset.msg, fd.dataset.type);

  /* Prevent double submit */
  document.querySelectorAll('form').forEach(f=>{
    f.addEventListener('submit',()=>{
      const b=f.querySelector('button[type=submit]');
      if(b){ setTimeout(()=>{ b.disabled=true; b.style.opacity='.65'; },40); }
    });
  });
});

function showToast(msg, type='success'){
  const t=document.createElement('div');
  t.className='toast '+(type==='success'?'t-ok':'t-err');
  t.innerHTML='<span>'+(type==='success'?'✓':'✕')+'</span> '+msg;
  document.body.appendChild(t);
  requestAnimationFrame(()=>requestAnimationFrame(()=>t.classList.add('show')));
  setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),450); },3200);
}

function togglePwd(id,btn){
  const f=document.getElementById(id);
  if(!f) return;
  f.type=f.type==='password'?'text':'password';
  btn.textContent=f.type==='password'?'Show':'Hide';
}
