</main>

<footer class="footer">
  <div class="ft-top">
    <div class="container ft-grid">
      <div class="ft-about">
        <a href="<?= SITE_URL ?>/index.php" class="logo">
          <span class="logo-mark">◈</span><span>Shop<em>Sphere</em></span>
        </a>
        <p>Curated premium products for modern living. Quality, style, and value — all in one place.</p>
        <div class="ft-socials">
          <a href="#" class="s-ico" title="Instagram">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
          </a>
          <a href="#" class="s-ico" title="Twitter/X">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
          </a>
        </div>
      </div>
      <div class="ft-col">
        <h4>Shop</h4>
        <a href="<?= SITE_URL ?>/products.php">All Products</a>
        <a href="<?= SITE_URL ?>/products.php?category=Electronics">Electronics</a>
        <a href="<?= SITE_URL ?>/products.php?category=Fashion">Fashion</a>
        <a href="<?= SITE_URL ?>/products.php?category=Accessories">Accessories</a>
      </div>
      <div class="ft-col">
        <h4>Account</h4>
        <a href="<?= SITE_URL ?>/register.php">Create Account</a>
        <a href="<?= SITE_URL ?>/login.php">Sign In</a>
        <a href="<?= SITE_URL ?>/cart.php">My Cart</a>
      </div>
      <div class="ft-col">
        <h4>Contact</h4>
        <p>📧 support@shopsphere.local</p>
        <p>📞 +91 98765 43210</p>
        <p style="margin-top:16px;font-size:.82rem;background:#1a1a1a;border:1px solid #222;padding:12px;border-radius:10px;">
          🚀 Running on XAMPP<br>localhost/shopsphere
        </p>
      </div>
    </div>
  </div>
  <div class="ft-btm">
    <div class="container ft-btm-inner">
      <span>© <?= date('Y') ?> ShopSphere — PHP + MySQL on XAMPP</span>
      <span>Built with ♥ for learning & projects</span>
    </div>
  </div>
</footer>

<script src="<?= SITE_URL ?>/assets/js/app.js"></script>
</body>
</html>
