<?php
require_once __DIR__ . '/../config.php';
$cur = basename($_SERVER['PHP_SELF'], '.php');
$cnt = cartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= isset($pageTitle) ? e($pageTitle).' — ' : '' ?>ShopSphere</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>

<?php if(isset($_SESSION['flash'])): ?>
<div id="flashData" data-type="<?= e($_SESSION['flash']['type']) ?>" data-msg="<?= e($_SESSION['flash']['msg']) ?>"></div>
<?php unset($_SESSION['flash']); endif; ?>

<div class="page-loader" id="pageLoader"><div class="loader-ring"></div></div>

<header class="header" id="siteHeader">
  <div class="hdr-inner">

    <a href="<?= SITE_URL ?>/index.php" class="logo">
      <span class="logo-mark">◈</span>
      <span>Shop<em>Sphere</em></span>
    </a>

    <nav class="nav" id="mainNav">
      <a href="<?= SITE_URL ?>/index.php"                              class="nl <?= $cur==='index'    ?'act':'' ?>">Home</a>
      <a href="<?= SITE_URL ?>/products.php"                           class="nl <?= $cur==='products' ?'act':'' ?>">All Products</a>
      <a href="<?= SITE_URL ?>/products.php?category=Electronics"      class="nl">Electronics</a>
      <a href="<?= SITE_URL ?>/products.php?category=Fashion"          class="nl">Fashion</a>
      <a href="<?= SITE_URL ?>/products.php?category=Accessories"      class="nl">Accessories</a>
    </nav>

    <div class="hdr-right">
      <button class="ico-btn" id="searchToggle" title="Search">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      </button>

      <a href="<?= SITE_URL ?>/cart.php" class="ico-btn cart-ico">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        <?php if($cnt>0): ?><span class="cart-dot"><?= $cnt ?></span><?php endif; ?>
      </a>

      <?php if(isLoggedIn()): ?>
        <div class="u-menu">
          <button class="u-btn" id="uBtn">
            <span class="u-av"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></span>
            <span><?= e(explode(' ',$_SESSION['user_name'])[0]) ?></span>
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div class="u-drop" id="uDrop">
            <div class="u-drop-top">
              <strong><?= e($_SESSION['user_name']) ?></strong>
              <span><?= e($_SESSION['user_email'] ?? '') ?></span>
            </div>
            <a href="<?= SITE_URL ?>/cart.php">🛒 My Cart</a>
            <a href="<?= SITE_URL ?>/logout.php" class="logout-link">↩ Sign Out</a>
          </div>
        </div>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php"    class="btn-outline">Login</a>
        <a href="<?= SITE_URL ?>/register.php" class="btn-solid">Sign Up</a>
      <?php endif; ?>

      <button class="hamburger" id="hamburger">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>

  <div class="search-drop" id="searchDrop">
    <form action="<?= SITE_URL ?>/products.php" method="GET" class="s-form">
      <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="text" name="search" placeholder="Search products…" autofocus>
      <button type="submit">Search</button>
    </form>
  </div>
</header>

<main>
