<?php
$pageTitle='Login';
require_once 'partials/header.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $email=trim($_POST['email']??'');
    $pwd=$_POST['password']??'';
    if($email===''||$pwd===''){$error='Please fill in all fields.';}
    else {
        $stmt=$conn->prepare("SELECT id,name,email,password FROM users WHERE email=?");
        $stmt->bind_param('s',$email);
        $stmt->execute();
        $u=$stmt->get_result()->fetch_assoc();
        if($u&&password_verify($pwd,$u['password'])){
            $_SESSION['user_id']=$u['id'];$_SESSION['user_name']=$u['name'];$_SESSION['user_email']=$u['email'];
            redirect('/index.php');
        } else {$error='Invalid email or password.';}
    }
}
?>
<div class="auth-page">
  <div class="auth-panel">
    <a href="<?= SITE_URL ?>/index.php" class="logo" style="margin-bottom:36px;display:flex;">
      <span class="logo-mark">◈</span><span>Shop<em>Sphere</em></span>
    </a>
    <h2>Welcome back</h2>
    <p>Sign in to access your cart and exclusive deals</p>
    <div class="auth-feats">
      <div>⚡ Instant cart access</div>
      <div>🎁 Member-only offers</div>
      <div>🚚 Free shipping perks</div>
    </div>
  </div>
  <div class="auth-form-wrap">
    <div class="auth-card">
      <h2>Sign In</h2>
      <p class="auth-sub">New here? <a href="<?= SITE_URL ?>/register.php">Create account →</a></p>
      <?php if($error): ?><div class="alert alert-err"><?= e($error) ?></div><?php endif; ?>
      <form method="POST" class="aform">
        <div class="fg2"><label>Email</label>
          <input type="email" name="email" placeholder="you@email.com" value="<?= e($_POST['email']??'') ?>" required>
        </div>
        <div class="fg2"><label>Password</label>
          <div class="pw-wrap">
            <input type="password" name="password" id="pw1" placeholder="Your password" required>
            <button type="button" class="pw-tog" onclick="togglePwd('pw1',this)">Show</button>
          </div>
        </div>
        <button type="submit" class="btn-auth-submit">Sign In →</button>
      </form>
    </div>
  </div>
</div>
<?php require_once 'partials/footer.php'; ?>
