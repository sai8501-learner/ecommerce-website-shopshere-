<?php
$pageTitle = 'Products';
require_once 'partials/header.php';

$search   = trim($_GET['search'] ?? '');
$category = trim($_GET['category'] ?? '');
$sort     = $_GET['sort'] ?? 'newest';

$sql = "SELECT id, name, category, price, image_url FROM products WHERE 1=1";
$params = [];
$types  = '';

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)";
    $lk = '%' . $search . '%';
    $params = array_merge($params, [$lk, $lk, $lk]);
    $types .= 'sss';
}

if ($category !== '') {
    $sql .= " AND category = ?";
    $params[] = $category;
    $types .= 's';
}

switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY price DESC";
        break;
    case 'name':
        $sql .= " ORDER BY name ASC";
        break;
    default:
        $sql .= " ORDER BY id DESC";
}

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$total  = $result->num_rows;

$allCats = $conn->query("SELECT DISTINCT category FROM products ORDER BY category");
?>

<div class="page-hero">
  <div class="container">
    <h1>
      <?= $category
          ? e($category)
          : ($search
              ? "Results for '" . e($search) . "'"
              : "All Products") ?>
    </h1>
    <p><?= $total ?> product<?= $total !== 1 ? 's' : '' ?> found</p>
  </div>
</div>

<section class="prods-wrap">
  <div class="container prods-layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="sb-card">
        <h3 class="sb-title">Filters</h3>
        <form method="GET" id="fForm">
          <input type="hidden" name="sort" value="<?= e($sort) ?>">

          <?php if ($search): ?>
            <input type="hidden" name="search" value="<?= e($search) ?>">
          <?php endif; ?>

          <div class="fg">
            <label class="flabel">Category</label>
            <div class="fopts">
              <label class="fopt <?= $category === '' ? 'on' : '' ?>">
                <input type="radio" name="category" value="" <?= $category === '' ? 'checked' : '' ?> onchange="this.form.submit()">
                All
              </label>

              <?php
              if ($allCats && $allCats->num_rows > 0):
                  $allCats->data_seek(0);
                  while ($c = $allCats->fetch_assoc()):
              ?>
                <label class="fopt <?= $category === $c['category'] ? 'on' : '' ?>">
                  <input type="radio" name="category" value="<?= e($c['category']) ?>" <?= $category === $c['category'] ? 'checked' : '' ?> onchange="this.form.submit()">
                  <?= e($c['category']) ?>
                </label>
              <?php
                  endwhile;
              endif;
              ?>
            </div>
          </div>

          <?php if ($category || $search): ?>
            <a href="<?= SITE_URL ?>/products.php" class="clear-f">✕ Clear Filters</a>
          <?php endif; ?>
        </form>
      </div>
    </aside>

    <!-- MAIN -->
    <div class="prods-main">
      <div class="toolbar">
        <form method="GET" class="tb-search">
          <input type="hidden" name="category" value="<?= e($category) ?>">
          <input type="text" name="search" placeholder="Search products…" value="<?= e($search) ?>">
          <button type="submit">Go</button>
        </form>

        <form method="GET" class="tb-sort">
          <input type="hidden" name="category" value="<?= e($category) ?>">

          <?php if ($search): ?>
            <input type="hidden" name="search" value="<?= e($search) ?>">
          <?php endif; ?>

          <select name="sort" onchange="this.form.submit()">
            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
            <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price ↑</option>
            <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price ↓</option>
            <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Name A–Z</option>
          </select>
        </form>
      </div>

      <?php if ($total > 0): ?>
        <div class="prod-grid">
          <?php $i = 0; while ($row = $result->fetch_assoc()): $i++; ?>
            <div class="pcard" style="--d:<?= $i * .04 ?>s">
              <div class="pcard-img">
                <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>">
                  <img src="<?= e($row['image_url']) ?>" alt="<?= e($row['name']) ?>" loading="lazy">
                </a>

                <div class="pcard-ov">
                  <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>" class="ov-btn">View Details</a>
                </div>

                <span class="pcard-cat"><?= e($row['category']) ?></span>
              </div>

              <div class="pcard-body">
                <h3>
                  <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>">
                    <?= e($row['name']) ?>
                  </a>
                </h3>

                <div class="pcard-foot">
                  <span class="pcard-price"><?= price((float)$row['price']) ?></span>

                  <form action="<?= SITE_URL ?>/add_to_cart.php" method="POST">
                    <input type="hidden" name="product_id" value="<?= (int)$row['id'] ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button class="add-btn" type="submit">
                      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
                        <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 0 1-8 0"/>
                      </svg>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <div class="es-icon">🔍</div>
          <h3>No products found</h3>
          <p>Try different keywords or clear your filters</p>
          <a href="<?= SITE_URL ?>/products.php" class="btn-solid" style="margin-top:20px;display:inline-block;">Browse All</a>
        </div>
      <?php endif; ?>
    </div>

  </div>
</section>

<?php require_once 'partials/footer.php'; ?>