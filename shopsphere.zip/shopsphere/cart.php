<?php
$pageTitle = 'My Cart';
require_once 'partials/header.php';
$cart  = $_SESSION['cart'];
$total = cartTotal();
$cnt   = cartCount();
?>

<div class="page-hero">
  <div class="container">
    <h1>Shopping Cart</h1>
    <p><?= $cnt ?> item<?= $cnt!==1?'s':'' ?> in your cart</p>
  </div>
</div>

<section class="cart-wrap">
  <div class="container cart-layout">

    <?php if(empty($cart)): ?>
    <div class="empty-state" style="grid-column:1/-1">
      <div class="es-icon">🛒</div>
      <h3>Your cart is empty</h3>
      <p>You haven't added any products yet</p>
      <a href="<?= SITE_URL ?>/products.php" class="btn-solid" style="margin-top:20px;display:inline-block;">Browse Products</a>
    </div>

    <?php else: ?>

    <!-- ITEMS -->
    <div class="cart-items">
      <div class="ci-header">
        <span>Product</span><span>Price</span><span>Quantity</span><span>Subtotal</span><span></span>
      </div>
      <?php foreach($cart as $item): $sub=$item['price']*$item['quantity']; ?>
      <div class="ci-row">
        <div class="ci-prod">
          <img src="<?= e($item['image_url']) ?>" alt="<?= e($item['name']) ?>">
          <div>
            <h4><?= e($item['name']) ?></h4>
            <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$item['id'] ?>" class="ci-link">View →</a>
          </div>
        </div>
        <span class="ci-price"><?= price((float)$item['price']) ?></span>
        <form action="<?= SITE_URL ?>/update_cart.php" method="POST" class="ci-qty-form">
          <input type="hidden" name="product_id" value="<?= (int)$item['id'] ?>">
          <div class="qty-sm">
            <button type="button" onclick="adj(this,-1)">−</button>
            <input type="number" name="quantity" value="<?= (int)$item['quantity'] ?>" min="0" max="99" onchange="this.form.submit()">
            <button type="button" onclick="adj(this,1)">+</button>
          </div>
        </form>
        <span class="ci-sub"><?= price((float)$sub) ?></span>
        <form action="<?= SITE_URL ?>/update_cart.php" method="POST">
          <input type="hidden" name="product_id" value="<?= (int)$item['id'] ?>">
          <input type="hidden" name="quantity"   value="0">
          <button type="submit" class="ci-del" title="Remove">✕</button>
        </form>
      </div>
      <?php endforeach; ?>
      <div class="ci-foot">
        <a href="<?= SITE_URL ?>/products.php" class="ghost-link">← Continue Shopping</a>
      </div>
    </div>

    <!-- SUMMARY -->
    <div class="cart-summary">
      <h3>Order Summary</h3>
      <div class="sum-row"><span>Subtotal</span><span><?= price($total) ?></span></div>
      <div class="sum-row"><span>Shipping</span>
        <?php if($total>=999): ?><span class="free-tag">FREE</span><?php else: ?><span><?= price(99) ?></span><?php endif; ?>
      </div>
      <div class="sum-row"><span>GST (18%)</span><span><?= price($total*0.18) ?></span></div>
      <div class="sum-div"></div>
      <div class="sum-row sum-total">
        <span>Total</span>
        <span><?= price($total + ($total>=999?0:99) + $total*0.18) ?></span>
      </div>
      <button class="btn-checkout" onclick="alert('Checkout — coming soon!\nThis is a demo project.')">Proceed to Checkout →</button>
      <div class="sum-trust"><span>🔒 Secure</span><span>↩️ Free Returns</span><span>🚚 Fast Delivery</span></div>
    </div>

    <?php endif; ?>
  </div>
</section>

<script>
function adj(btn,d){
  const form=btn.closest('form'), inp=form.querySelector('input[type=number]');
  inp.value=Math.max(0,Math.min(99,(parseInt(inp.value)||1)+d));
  form.submit();
}
</script>

<?php require_once 'partials/footer.php'; ?>
