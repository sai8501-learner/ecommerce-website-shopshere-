-- ShopSphere Database
-- Import this file in phpMyAdmin

CREATE DATABASE IF NOT EXISTS shop_db;
USE shop_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(120) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    category    VARCHAR(80)  NOT NULL,
    description TEXT         NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    image_url   VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample products (uses Unsplash images — internet required)
INSERT INTO products (name, category, description, price, image_url) VALUES
('Wireless Headphones',  'Electronics',  'Premium over-ear headphones with immersive sound, noise cancellation, and 30-hour battery life.',  2999.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80'),
('Smart Watch',          'Electronics',  'Stylish smartwatch with health tracking, GPS, and instant notifications on your wrist.',            4599.00, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80'),
('Minimal Backpack',     'Accessories',  'Sleek daily backpack designed for college, travel, and office use with multiple compartments.',      1899.00, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'),
('Casual Sneakers',      'Fashion',      'Comfortable and trendy sneakers crafted for all-day everyday wear with memory foam insole.',         2499.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80'),
('Classic Sunglasses',   'Accessories',  'UV-400 protected polarized sunglasses with a lightweight premium frame for style and comfort.',       999.00, 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80'),
('Bluetooth Speaker',    'Electronics',  'Portable waterproof Bluetooth speaker with 360-degree sound and 12-hour battery life.',             3499.00, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=800&q=80'),
('Denim Jacket',         'Fashion',      'Classic denim jacket with a modern slim fit, perfect for casual and semi-formal occasions.',         1599.00, 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80'),
('Leather Wallet',       'Accessories',  'Genuine leather slim wallet with RFID blocking protection and multiple card slots.',                  799.00, 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80');
