-- ============================================================
--  ShopSphere Database
--  Import this file via phpMyAdmin → Import tab
-- ============================================================

CREATE DATABASE IF NOT EXISTS shopsphere_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE shopsphere_db;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(120) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Products
CREATE TABLE IF NOT EXISTS products (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  category    VARCHAR(80)  NOT NULL,
  description TEXT         NOT NULL,
  price       DECIMAL(10,2) NOT NULL,
  image_url   VARCHAR(500) NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample Data (12 products, 3 categories)
INSERT INTO products (name, category, description, price, image_url) VALUES

('Wireless Noise-Cancelling Headphones','Electronics',
 'Premium over-ear headphones with active noise cancellation, 40-hour battery life, Hi-Res audio support and foldable design. Perfect for music lovers and remote workers.',
 2999.00,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80'),

('Smart Watch Pro X','Electronics',
 'Advanced smartwatch with AMOLED display, health monitoring (SpO2, heart rate, sleep tracking), built-in GPS and 7-day battery life. Water resistant up to 50m.',
 4599.00,'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80'),

('Bluetooth Portable Speaker','Electronics',
 'Waterproof 360-degree portable speaker with 24W powerful output, 12-hour battery, USB-C fast charging and built-in speakerphone.',
 3499.00,'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=800&q=80'),

('Mechanical Gaming Keyboard','Electronics',
 'Full-size mechanical keyboard with Cherry MX Red switches, per-key RGB backlighting, 100% anti-ghosting and durable aluminum top frame.',
 5999.00,'https://images.unsplash.com/photo-1541140532154-b024d705b90a?auto=format&fit=crop&w=800&q=80'),

('True Wireless Earbuds','Electronics',
 'Compact TWS earbuds with 6mm dynamic drivers, 28-hour total playback with charging case, IPX4 water resistance and touch controls.',
 1799.00,'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80'),

('USB-C Fast Charger 65W','Electronics',
 'GaN technology 65W fast charger with 3 ports (2x USB-C + 1x USB-A), compatible with laptops, phones, and tablets. Foldable plug design.',
 1299.00,'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=800&q=80'),

('Casual Sneakers Urban','Fashion',
 'Lightweight and breathable everyday sneakers with memory foam insole, durable rubber outsole and minimalist design that pairs with anything.',
 2499.00,'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80'),

('Classic Denim Jacket','Fashion',
 'Premium raw denim jacket with modern slim cut, reinforced double stitching and antique brass buttons. A timeless wardrobe essential.',
 1599.00,'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80'),

('Organic Cotton Oversized Tee','Fashion',
 '100% organic cotton oversized t-shirt with relaxed drop-shoulder fit. Pre-washed for softness. Sustainably produced. Available in 12 colors.',
 699.00,'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80'),

('Minimal Canvas Backpack','Accessories',
 'Versatile 25L canvas backpack with padded 15" laptop sleeve, multiple organizer pockets, water-resistant coating and adjustable straps.',
 1899.00,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'),

('Polarized Aviator Sunglasses','Accessories',
 'UV-400 polarized lenses with ultra-lightweight stainless steel frame, anti-scratch coating. Includes premium hard case and microfiber cloth.',
 999.00,'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80'),

('Slim RFID Leather Wallet','Accessories',
 'Genuine full-grain leather slim wallet with RFID-blocking technology, 6 card slots, cash compartment, and an ultra-thin 8mm profile.',
 799.00,'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80');
