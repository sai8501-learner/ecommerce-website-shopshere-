<?php
require_once 'config.php';
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('/products.php');

$pid = (int)($_POST['product_id'] ?? 0);
$qty = max(1,(int)($_POST['quantity'] ?? 1));

$stmt=$conn->prepare("SELECT id,name,price,image_url FROM products WHERE id=?");
$stmt->bind_param('i',$pid);
$stmt->execute();
$p=$stmt->get_result()->fetch_assoc();
if(!$p) redirect('/products.php');

if(isset($_SESSION['cart'][$pid])){
    $_SESSION['cart'][$pid]['quantity']+=$qty;
} else {
    $_SESSION['cart'][$pid]=['id'=>(int)$p['id'],'name'=>$p['name'],'price'=>(float)$p['price'],'image_url'=>$p['image_url'],'quantity'=>$qty];
}
$_SESSION['flash']=['type'=>'success','msg'=>'"'.htmlspecialchars($p['name'],ENT_QUOTES).'" added to cart!'];
redirect('/cart.php');
