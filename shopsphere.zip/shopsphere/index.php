<?php
$pageTitle = 'Home';
require_once 'partials/header.php';
$stmt = $conn->prepare("SELECT id,name,price,image_url,category FROM products ORDER BY id DESC LIMIT 8");
$stmt->execute();
$featured = $stmt->get_result();
?>

<!-- ===== HERO ===== -->
<section class="hero">
  <div class="hero-bg">
    <div class="orb o1"></div><div class="orb o2"></div><div class="orb o3"></div>
  </div>
  <div class="container hero-inner">
    <div class="hero-text">
      <div class="hero-chip">✦ New Season — 2025 Collection</div>
      <h1>Elevate Your<br><em>Everyday Style</em></h1>
      <p>Premium electronics, fashion & accessories — curated for people who demand the best.</p>
      <div class="hero-btns">
        <a href="<?= SITE_URL ?>/products.php" class="btn-hero">Shop Now →</a>
        <a href="<?= SITE_URL ?>/products.php?category=Electronics" class="btn-hero-ghost">Electronics ↗</a>
      </div>
      <div class="hero-nums">
        <div class="num"><strong>500+</strong><span>Products</span></div>
        <div class="num-sep"></div>
        <div class="num"><strong>12K+</strong><span>Happy Buyers</span></div>
        <div class="num-sep"></div>
        <div class="num"><strong>4.9★</strong><span>Avg Rating</span></div>
      </div>
    </div>
    <div class="hero-cards">
      <div class="hc hc1">
        <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80" alt="">
        <span>Headphones · ₹2,999</span>
      </div>
      <div class="hc hc2">
        <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80" alt="">
        <span>Smart Watch · ₹4,599</span>
      </div>
      <div class="hc-badge">FREE<br>SHIP</div>
    </div>
  </div>
</section>

<!-- ===== TRUST BAR ===== -->
<div class="trust-bar">
  <div class="container trust-row">
    <div class="trust-item"><span>🚚</span><div><strong>Free Delivery</strong><p>Orders above ₹999</p></div></div>
    <div class="trust-item"><span>🔒</span><div><strong>Secure Payments</strong><p>100% protected</p></div></div>
    <div class="trust-item"><span>↩️</span><div><strong>30-Day Returns</strong><p>Hassle-free policy</p></div></div>
    <div class="trust-item"><span>🎧</span><div><strong>24/7 Support</strong><p>Always available</p></div></div>
  </div>
</div>

<!-- ===== CATEGORIES ===== -->
<section class="section">
  <div class="container">
    <div class="sec-head">
      <div><p class="sec-tag">Browse By</p><h2 class="sec-title">Categories</h2></div>
    </div>
    <div class="cat-grid">
      <a href="<?= SITE_URL ?>/products.php?category=Electronics" class="cat-card cc-elec">
        <div class="cat-icon">⚡</div>
        <h3>Electronics</h3><p>Gadgets & gear</p>
        <span class="cat-arrow">→</span>
      </a>
      <a href="<?= SITE_URL ?>/products.php?category=Fashion" class="cat-card cc-fashion">
        <div class="cat-icon">👗</div>
        <h3>Fashion</h3><p>Style & trends</p>
        <span class="cat-arrow">→</span>
      </a>
      <a href="<?= SITE_URL ?>/products.php?category=Accessories" class="cat-card cc-acc">
        <div class="cat-icon">💎</div>
        <h3>Accessories</h3><p>Complete your look</p>
        <span class="cat-arrow">→</span>
      </a>
    </div>
  </div>
</section>

<!-- ===== FEATURED PRODUCTS ===== -->
<section class="section bg-section">
  <div class="container">
    <div class="sec-head">
      <div><p class="sec-tag">Hand-Picked</p><h2 class="sec-title">Featured Products</h2></div>
      <a href="<?= SITE_URL ?>/products.php" class="see-all">View All →</a>
    </div>
    <div class="prod-grid">
      <?php $i=0; while($row=$featured->fetch_assoc()): $i++; ?>
      <div class="pcard" style="--d:<?= $i*.06 ?>s">
        <div class="pcard-img">
          <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>">
            <img src="<?= e($row['image_url']) ?>" alt="<?= e($row['name']) ?>" loading="lazy">
          </a>
          <div class="pcard-ov">
            <a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>" class="ov-btn">Quick View</a>
          </div>
          <span class="pcard-cat"><?= e($row['category']) ?></span>
        </div>
        <div class="pcard-body">
          <h3><a href="<?= SITE_URL ?>/product.php?id=<?= (int)$row['id'] ?>"><?= e($row['name']) ?></a></h3>
          <div class="pcard-foot">
            <span class="pcard-price"><?= price((float)$row['price']) ?></span>
            <form action="<?= SITE_URL ?>/add_to_cart.php" method="POST">
              <input type="hidden" name="product_id" value="<?= (int)$row['id'] ?>">
              <input type="hidden" name="quantity"   value="1">
              <button class="add-btn" type="submit" title="Add to cart">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              </button>
            </form>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<!-- ===== PROMO STRIP ===== -->
<section class="promo-strip">
  <div class="container promo-inner">
    <div>
      <span class="promo-chip">Limited Time</span>
      <h2>Get 20% Off Your First Order</h2>
      <p>Create a free account and use code <strong>WELCOME20</strong> at checkout</p>
      <a href="<?= SITE_URL ?>/register.php" class="btn-hero" style="margin-top:20px;display:inline-block;">Claim Offer →</a>
    </div>
  </div>
</section>

<?php require_once 'partials/footer.php'; ?>
