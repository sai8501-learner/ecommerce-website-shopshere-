<?php
$pageTitle='Register';
require_once 'partials/header.php';
$error=''; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim($_POST['name']??'');
    $email=trim($_POST['email']??'');
    $pwd=$_POST['password']??'';
    $conf=$_POST['confirm']??'';
    if($name===''||$email===''||$pwd===''){$error='All fields are required.';}
    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){$error='Invalid email address.';}
    elseif(strlen($pwd)<6){$error='Password must be at least 6 characters.';}
    elseif($pwd!==$conf){$error='Passwords do not match.';}
    else {
        $chk=$conn->prepare("SELECT id FROM users WHERE email=?");
        $chk->bind_param('s',$email);$chk->execute();
        if($chk->get_result()->fetch_assoc()){$error='This email is already registered.';}
        else {
            $h=password_hash($pwd,PASSWORD_DEFAULT);
            $ins=$conn->prepare("INSERT INTO users(name,email,password)VALUES(?,?,?)");
            $ins->bind_param('sss',$name,$email,$h);
            $ins->execute()?($success='Account created! You can now login.'):($error='Something went wrong.');
        }
    }
}
?>
<div class="auth-page">
  <div class="auth-panel">
    <a href="<?= SITE_URL ?>/index.php" class="logo" style="margin-bottom:36px;display:flex;">
      <span class="logo-mark">◈</span><span>Shop<em>Sphere</em></span>
    </a>
    <h2>Join thousands of happy shoppers</h2>
    <p>Create your free account and enjoy premium shopping experience.</p>
    <div class="auth-feats">
      <div>🎁 20% off first order</div>
      <div>⚡ Fast checkout always</div>
      <div>🔔 Exclusive deal alerts</div>
    </div>
  </div>
  <div class="auth-form-wrap">
    <div class="auth-card">
      <h2>Create Account</h2>
      <p class="auth-sub">Have an account? <a href="<?= SITE_URL ?>/login.php">Sign in →</a></p>
      <?php if($error): ?><div class="alert alert-err"><?= e($error) ?></div><?php endif; ?>
      <?php if($success): ?><div class="alert alert-ok"><?= e($success) ?> <a href="<?= SITE_URL ?>/login.php">Login →</a></div><?php endif; ?>
      <form method="POST" class="aform">
        <div class="fg2"><label>Full Name</label>
          <input type="text" name="name" placeholder="Your name" value="<?= e($_POST['name']??'') ?>" required>
        </div>
        <div class="fg2"><label>Email</label>
          <input type="email" name="email" placeholder="you@email.com" value="<?= e($_POST['email']??'') ?>" required>
        </div>
        <div class="fg2"><label>Password</label>
          <div class="pw-wrap">
            <input type="password" name="password" id="pw1" placeholder="Min 6 characters" required>
            <button type="button" class="pw-tog" onclick="togglePwd('pw1',this)">Show</button>
          </div>
        </div>
        <div class="fg2"><label>Confirm Password</label>
          <input type="password" name="confirm" placeholder="Repeat password" required>
        </div>
        <button type="submit" class="btn-auth-submit">Create Account →</button>
      </form>
    </div>
  </div>
</div>
<?php require_once 'partials/footer.php'; ?>
